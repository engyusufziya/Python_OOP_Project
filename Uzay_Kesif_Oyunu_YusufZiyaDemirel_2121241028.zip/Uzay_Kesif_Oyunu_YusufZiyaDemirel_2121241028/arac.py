# Yusuf Ziya Demirel - Öğrenci No: 2121241028
# Uzay Keşif Oyunu - Arac Sınıfı

class Arac:
    def __init__(self):
        # Başlangıç değerleri
        self.yakit = 100
        self.kapasite = 50
        self.kaynak = 0
        self.konum_x = 0
        self.konum_y = 0
        self.durum = "Hazır"

    def konum_goster(self):
        print("Konum: (", self.konum_x, ",", self.konum_y, ")")

    def durum_goster(self):
        print("Yakıt:", self.yakit)
        print("Kapasite:", self.kapasite)
        print("Kaynak:", self.kaynak)
        self.konum_goster()
        print("Durum:", self.durum)

    def hareket_et(self, hedef_x, hedef_y):
        # Öklidyen mesafe
        dx = hedef_x - self.konum_x
        dy = hedef_y - self.konum_y
        mesafe = (dx * dx + dy * dy) ** 0.5
        tuketim = int(mesafe * 10)

        if self.yakit >= tuketim:
            self.yakit = self.yakit - tuketim
            self.konum_x = hedef_x
            self.konum_y = hedef_y
            self.durum = "Seyahat"
            print("Hareket edildi.")
            print("Tüketilen yakıt:", tuketim)
        else:
            print("Yetersiz yakıt. Hareket edilemedi.")

    def kaynak_topla(self, miktar):
        if miktar <= 0:
            print("Geçersiz miktar.")
        elif self.kaynak + miktar <= self.kapasite:
            self.kaynak = self.kaynak + miktar
            print("Kaynak toplandı. Toplam:", self.kaynak)
        else:
            kalan = self.kapasite - self.kaynak
            if kalan > 0:
                self.kaynak = self.kapasite
                print("Kapasite doldu. Sadece", kalan, "birim kaynak toplandı.")
            else:
                print("Kaynak deposu tamamen dolu.")

    def yakit_yenile(self, kaynak_miktari):
        if kaynak_miktari > 0 and self.kaynak >= kaynak_miktari:
            eklenen = kaynak_miktari * 2
            self.kaynak = self.kaynak - kaynak_miktari
            self.yakit = self.yakit + eklenen
            print("Yakıt yenilendi. Yeni yakıt:", self.yakit)
        else:
            print("Yetersiz kaynak ile yakıt yenilenemez.")

    def kapasite_arttir(self, kaynak_miktari):
        if kaynak_miktari > 0 and self.kaynak >= kaynak_miktari:
            artis = kaynak_miktari * 5
            self.kaynak = self.kaynak - kaynak_miktari
            self.kapasite = self.kapasite + artis
            print("Kapasite arttırıldı. Yeni kapasite:", self.kapasite)
        else:
            print("Yetersiz kaynak ile kapasite arttırılamaz.")
