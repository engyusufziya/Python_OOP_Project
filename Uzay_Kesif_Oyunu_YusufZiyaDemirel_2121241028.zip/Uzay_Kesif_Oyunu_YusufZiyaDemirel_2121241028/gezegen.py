# Yusuf Ziya Demirel - Öğrenci No: 2121241028
# Uzay Keşif Oyunu - Gezegen Sınıfı

class Gezegen:
    def __init__(self, isim, x, y, kaynak, atmosfer, yercekimi):
        self.isim = isim
        self.konum_x = x
        self.konum_y = y
        self.kaynak = kaynak
        self.atmosfer = atmosfer  # "Yaşanabilir", "Zehirli", "Yoğun"
        self.yercekimi = yercekimi
        self.yakit_istasyonu = self.yakit_istasyonu_var_mi()

    def yakit_istasyonu_var_mi(self):
        if self.atmosfer == "Yaşanabilir":
            return True
        elif self.atmosfer == "Zehirli":
            return False
        elif self.atmosfer == "Yoğun":
            return False
        else:
            return False

    def iniş_maliyeti(self):
        if self.atmosfer == "Yaşanabilir":
            maliyet = self.yercekimi // 2
            if maliyet < 5:
                maliyet = 5
            return maliyet
        elif self.atmosfer == "Zehirli":
            if self.yercekimi < 10:
                return 10
            else:
                return self.yercekimi
        elif self.atmosfer == "Yoğun":
            if self.yercekimi > 15:
                return -1  # İniş yapılamaz
            else:
                return self.yercekimi + 10
        else:
            return -1

    def inis_yap(self, arac):
        maliyet = self.iniş_maliyeti()
        if maliyet == -1:
            print(self.isim, "gezegenine iniş yapılamıyor.")
        elif arac.yakit >= maliyet:
            arac.yakit = arac.yakit - maliyet
            arac.konum_x = self.konum_x
            arac.konum_y = self.konum_y
            arac.durum = "Keşif"
            print(self.isim, "gezegenine iniş yapıldı.")
            print("Yakıt maliyeti:", maliyet)
        else:
            print("Yetersiz yakıt nedeniyle iniş yapılamadı.")

    def kaynak_cikar(self, arac, miktar):
        if self.kaynak <= 0:
            print("Gezegende kaynak kalmadı.")
        elif miktar <= 0:
            print("Geçersiz miktar.")
        elif miktar > self.kaynak:
            miktar = self.kaynak
            sonuc = arac.kaynak_topla(miktar)
            if sonuc:
                self.kaynak = 0
        else:
            sonuc = arac.kaynak_topla(miktar)
            if sonuc:
                self.kaynak = self.kaynak - miktar

    def yakit_doldur(self, arac, miktar):
        if self.yakit_istasyonu == False:
            print("Bu gezegende yakıt istasyonu yok.")
        elif miktar <= 0:
            print("Geçersiz miktar.")
        else:
            ucret = miktar // 4
            if arac.kaynak >= ucret:
                arac.kaynak = arac.kaynak - ucret
                arac.yakit = arac.yakit + miktar
                print("Yakıt yüklendi.")
            else:
                print("Yetersiz kaynak. Yakıt alınamadı.")

    def bilgi_yazdir(self):
        print("\nGezegen Adı:", self.isim)
        print("Konum:", self.konum_x, ",", self.konum_y)
        print("Kaynak:", self.kaynak)
        print("Atmosfer:", self.atmosfer)
        print("Yerçekimi:", self.yercekimi)
        if self.yakit_istasyonu:
            print("Yakıt İstasyonu: Var")
        else:
            print("Yakıt İstasyonu: Yok")

    def kesfedildi_mi(self, arac):
        if arac.konum_x == self.konum_x and arac.konum_y == self.konum_y:
            return True
        else:
            return False
