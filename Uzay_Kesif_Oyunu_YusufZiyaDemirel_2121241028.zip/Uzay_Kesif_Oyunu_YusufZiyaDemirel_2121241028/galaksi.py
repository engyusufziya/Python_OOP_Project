# Yusuf Ziya Demirel - Öğrenci No: 2121241028
# Uzay Keşif Oyunu - Galaksi Oluşturma

from gezegen import Gezegen
from karadelik import Karadelik
import random

def galaksi_olustur():
    galaksi = []

    # Rastgele 5 gezegen oluştur
    isimler = ["Dünya", "Mars", "Venüs", "Jüpiter", "Satürn"]
    atmosferler = ["Yaşanabilir", "Zehirli", "Yoğun"]

    for i in range(5):
        isim = isimler[i]
        x = random.randint(0, 10)
        y = random.randint(0, 10)
        kaynak = random.randint(20, 70)
        atmosfer = random.choice(atmosferler)
        yercekimi = random.randint(5, 20)

        gezegen = Gezegen(isim, x, y, kaynak, atmosfer, yercekimi)
        galaksi.append(gezegen)

    # Rastgele 3 karadelik oluştur
    for i in range(3):
        x = random.randint(0, 10)
        y = random.randint(0, 10)
        karadelik = Karadelik(x, y)
        galaksi.append(karadelik)

    return galaksi

def harita_goster(galaksi, arac):
    harita = []

    for y in range(11):
        satir = []
        for x in range(11):
            satir.append(".")
        harita.append(satir)

    # Harflerle gezegenleri yerleştir
    harfler = ["A", "B", "C", "D", "E"]
    sayac = 0

    for nesne in galaksi:
        if sayac < 5:
            harita[nesne.konum_y][nesne.konum_x] = harfler[sayac]
            sayac = sayac + 1
        else:
            harita[nesne.konum_y][nesne.konum_x] = "K"

    # Uzay aracını yerleştir
    harita[arac.konum_y][arac.konum_x] = "G"

    print("\n--- Galaksi Haritası ---")
    for y in range(11):
        satir = ""
        for x in range(11):
            satir = satir + harita[y][x] + " "
        print(satir)

    print("\nSemboller:")
    print("G = Uzay Aracı")
    for i in range(5):
        print(harfler[i], "=", galaksi[i].isim)
    print("K = Karadelik")

def nesne_getir(galaksi, x, y):
    for i in range(len(galaksi)):
        if galaksi[i].konum_x == x and galaksi[i].konum_y == y:
            return galaksi[i]
    return None

def galaksi_durumu(galaksi):
    print("\n--- Galaksideki Tüm Nesneler ---")
    for i in range(len(galaksi)):
        nesne = galaksi[i]
        nesne.bilgi_yazdir()
