# Yusuf Ziya Demirel - Öğrenci No: 2121241028
# Uzay Keşif Oyunu - Karadelik Sınıfı

import random

class Karadelik:
    def __init__(self, x, y):
        self.konum_x = x
        self.konum_y = y

    def etkilesim(self, arac, gezegenler):
        print("Bir karadelikle karşılaştınız.")

        # Hedef gezegen rastgele seçilir
        uzunluk = len(gezegenler)
        sayi = random.randint(0, uzunluk - 1)
        hedef = gezegenler[sayi]

        # 1 veya 2: rastgele etki seç
        secim = random.randint(1, 2)

        if secim == 1:
            print("Hiçbir yakıt harcamadan rastgele bir gezegene ışınlandınız.")
            arac.konum_x = hedef.konum_x
            arac.konum_y = hedef.konum_y

        elif secim == 2:
            print("Enerji kaybettiniz! Yakıt ve kaynak harcayarak ışınlanıyorsunuz.")

            yakit_kaybi = 20
            kaynak_kaybi = 10

            if arac.yakit < yakit_kaybi:
                yakit_kaybi = arac.yakit
            if arac.kaynak < kaynak_kaybi:
                kaynak_kaybi = arac.kaynak

            arac.yakit = arac.yakit - yakit_kaybi
            arac.kaynak = arac.kaynak - kaynak_kaybi

            arac.konum_x = hedef.konum_x
            arac.konum_y = hedef.konum_y

            print("Işınlama tamamlandı.")
            print("Kaybedilen yakıt:", yakit_kaybi)
            print("Kaybedilen kaynak:", kaynak_kaybi)

    def bilgi_yazdir(self):
        print("\nKaradelik Konumu:", self.konum_x, ",", self.konum_y)
        print("Etkileşime girilirse rastgele bir gezegene ışınlanır.")
        print("Bazen yakıt ve kaynak kaybı olur, bazen ücretsizdir.")
