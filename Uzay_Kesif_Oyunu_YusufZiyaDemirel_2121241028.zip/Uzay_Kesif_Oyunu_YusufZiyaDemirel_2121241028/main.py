# Yusuf Ziya Demirel - Öğrenci No: 2121241028
# Uzay Keşif Oyunu - Ana Oyun Döngüsü

from arac import Arac
from gezegen import Gezegen
from karadelik import Karadelik
from galaksi import galaksi_olustur, harita_goster, nesne_getir
import random

def oyun_sonu(galaksi, arac):
    if arac.yakit <= 0:
        print("\nOYUN BİTTİ: Yakıtınız tükendi.")
        return True

    sayac = 0
    for i in range(len(galaksi)):
        nesne = galaksi[i]
        if i < 5:  # İlk 5 nesne gezegen
            if nesne.konum_x == arac.konum_x and nesne.konum_y == arac.konum_y:
                sayac = sayac + 1

    if sayac == 5:
        print("\nTEBRİKLER! Tüm gezegenleri keşfettiniz.")
        return True

    return False

def menu_goster():
    print("\n--- UZAY KEŞİF OYUNU ---")
    print("1 - Haritayı Göster")
    print("2 - Hedef Belirle ve Git")
    print("3 - Konumdaki Nesneyle Etkileşim")
    print("4 - Aracın Durumunu Göster")
    print("5 - Oyunu Sonlandır")
    secim = input("Seçiminiz: ")
    return secim

def hedefe_git(arac, galaksi):
    try:
        x = int(input("Hedef X (0-10): "))
        y = int(input("Hedef Y (0-10): "))

        dx = x - arac.konum_x
        dy = y - arac.konum_y
        mesafe = (dx * dx + dy * dy) ** 0.5
        tuketim = int(mesafe * 10)

        if arac.yakit >= tuketim:
            arac.hareket_et(x, y)
            nesne = nesne_getir(galaksi, x, y)

            if nesne != None and galaksi.index(nesne) >= 5:
                # Karadelik
                gezegenler = galaksi[0:5]
                nesne.etkilesim(arac, gezegenler)
        else:
            print("Yetersiz yakıt.")
    except:
        print("Geçersiz giriş.")

def nesne_ile_etkilesim(arac, galaksi):
    nesne = nesne_getir(galaksi, arac.konum_x, arac.konum_y)

    if nesne == None:
        print("Bu konumda nesne yok.")
    else:
        index = galaksi.index(nesne)
        if index < 5:
            # Gezegen
            nesne.bilgi_yazdir()
            secim = input("İniş yapmak istiyor musunuz? (e/h): ")
            if secim == "e":
                nesne.inis_yap(arac)

                while True:
                    print("\nGezegen İşlemleri:")
                    print("1 - Kaynak Topla")
                    print("2 - Yakıt Yenile (1 kaynak = 2 yakıt)")
                    print("3 - Kapasite Artır (1 kaynak = 5 kapasite)")
                    if nesne.yakit_istasyonu:
                        print("4 - Yakıt İstasyonu (4 yakıt = 1 kaynak)")
                        print("5 - Ayrıl")
                        limit = 5
                    else:
                        print("4 - Ayrıl")
                        limit = 4

                    secim2 = input("Seçim: ")
                    if secim2 == "1":
                        miktar = int(input("Toplanacak miktar: "))
                        nesne.kaynak_cikar(arac, miktar)
                    elif secim2 == "2":
                        miktar = int(input("Kullanılacak kaynak miktarı: "))
                        arac.yakit_yenile(miktar)
                    elif secim2 == "3":
                        miktar = int(input("Kullanılacak kaynak miktarı: "))
                        arac.kapasite_arttir(miktar)
                    elif secim2 == "4" and nesne.yakit_istasyonu:
                        miktar = int(input("Yakıt almak istediginiz miktar: "))
                        nesne.yakit_doldur(arac, miktar)
                    elif secim2 == str(limit):
                        print("Gezegenden ayrılıyorsunuz.")
                        arac.durum = "Hazır"
                        break
                    else:
                        print("Geçersiz seçim.")
        else:
            print("Bu bir karadeliktir. Konumdan ayrılmak önerilir.")

def main():
    arac = Arac()
    galaksi = galaksi_olustur()

    print("Uzay Keşif Oyunu Başladı.")

    while True:
        if oyun_sonu(galaksi, arac):
            break

        secim = menu_goster()

        if secim == "1":
            harita_goster(galaksi, arac)
        elif secim == "2":
            hedefe_git(arac, galaksi)
        elif secim == "3":
            nesne_ile_etkilesim(arac, galaksi)
        elif secim == "4":
            arac.durum_goster()
        elif secim == "5":
            print("Oyun sonlandırılıyor.")
            break
        else:
            print("Geçersiz seçim.")

if __name__ == "__main__":
    main()
